KennCo header previews

Place the three supplied JPG files in an assets folder alongside the HTML files.
Pic1: assets/shutterstock_1653287707.jpg
Pic2: assets/shutterstock_521078383.jpg
Pic3: assets/iStock_000067504517_Full.jpg

Open any of the HTML files in Chrome.
